﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Web.WebPages;

namespace DisplayModesAndViewEngineSamples
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);



            DisplayModeProvider.Instance.Modes.RemoveAt(0);

            ViewEngines.Engines.Clear();
            ViewEngines.Engines.Add(new CustomViewEngine());




            /*
            //The condition that specifies if the DisplayMode should be used for a given request
            Func<HttpContextBase, bool> condition = (context) =>
            {
                //This is not the best way to do user agent detection. Please see the chapter on device
                //  and feature detection.
                return context.GetOverriddenUserAgent()
                    .IndexOf("MSIE 10.0; Windows Phone 8.0", StringComparison.OrdinalIgnoreCase) >= 0;
            };

            var wp8DisplayMode = new DefaultDisplayMode("wp8");
            wp8DisplayMode.ContextCondition = condition;

            DisplayModeProvider.Instance.Modes.Insert(0, wp8DisplayMode);
            */
        }
    }
}
