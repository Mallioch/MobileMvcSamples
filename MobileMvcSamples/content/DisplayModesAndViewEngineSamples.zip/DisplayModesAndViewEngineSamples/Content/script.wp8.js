﻿window.onload = function () {
    var output = document.getElementById('output');
    output.innerText = 'WP8 JavaScript';
}