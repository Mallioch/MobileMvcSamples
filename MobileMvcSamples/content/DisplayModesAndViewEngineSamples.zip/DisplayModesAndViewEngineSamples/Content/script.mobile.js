﻿window.onload = function () {
    var output = document.getElementById('output');
    output.innerText = 'Mobile JavaScript';
}